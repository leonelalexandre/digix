﻿using BolsaCasa.Infra.Persistence.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace BolsaCasa.CrossCutting.IOC.DependencyInjection
{
    public static class ConfigureBindingsRepository
    {
        public static void AddRepositories(this IServiceCollection services)
        {
            services.AddScoped<ParticipantRepository>();
        }
    }
}
