﻿using BolsaCasa.Infra.Persistence.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BolsaCasa.CrossCutting.IOC.DependencyInjection
{
    public static class ConfigureBindingsDatabaseContext
    {
        public static void AddDatabaseContext(this IServiceCollection services)
        {
            IConfiguration configuration = services.BuildServiceProvider().GetService<IConfiguration>();

            services
                .AddDbContextPool<BolsaCasaModel>(
                        options =>
                        {
                            options.UseSqlServer(configuration.GetConnectionString("bolsaCasa"));
                        });
        }
    }
}
