﻿using BolsaCasa.Service.Modules;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.CrossCutting.IOC.DependencyInjection
{
    public static class ConfigureBindingsService
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<IParticipantService, ParticipantService>();
        }
    }
}
