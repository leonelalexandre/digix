﻿using BolsaCasa.Service.Mappers;
using Microsoft.Extensions.DependencyInjection;

namespace BolsaCasa.CrossCutting.IOC.DependencyInjection
{
    public static class ConfigureBindingsMapper
    {
        public static void AddMappers(this IServiceCollection services)
        {
            services.AddAutoMapper(typeof(BaseProfile));
        }
    }
}
