﻿namespace BolsaCasa.CrossCutting.DTO.Participant
{
    public class PostParticipant
    {
        public string NameParticipant { get; set; }

        public decimal Income { get; set; }

        public int Point { get; set; }
    }
}

