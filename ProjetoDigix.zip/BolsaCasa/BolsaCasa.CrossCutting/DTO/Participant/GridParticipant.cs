﻿namespace BolsaCasa.CrossCutting.DTO.Participant
{
    public class GridParticipant
    {
        public int Id { get; set; }

        public string NameParticipant { get; set; }

        public decimal Income { get; set; }

        public int Point { get; set; }
    }
}
