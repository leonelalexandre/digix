﻿namespace BolsaCasa.CrossCutting.DTO.Dependent
{
    public class PostDependent
    {
        public int IdParticipant { get; set; }

        public string NameDependent { get; set; }

        public DateTime BirthDate { get; set; }

        public bool Active { get; set; }
    }
}
