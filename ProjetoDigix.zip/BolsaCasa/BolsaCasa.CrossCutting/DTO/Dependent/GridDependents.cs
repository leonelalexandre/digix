﻿namespace BolsaCasa.CrossCutting.DTO.Dependent
{
    public class GridDependents
    {
        public int Id { get; set; }

        public int IdParticipant { get; set; }

        public string NameDependent { get; set; }

        public DateTime BirthDate { get; set; }
    }
}
