﻿using AutoMapper;

namespace BolsaCasa.Service.Mappers
{
    public class BaseProfile : Profile
    {
    }
}
