﻿using BolsaCasa.CrossCutting.DTO.Participant;
using BolsaCasa.Domain.Entities;

namespace BolsaCasa.Service.Mappers
{
    public sealed class ParticipantProfile : BaseProfile
    {
        public ParticipantProfile()
        {
            CreateMap<PostParticipant, ParticipantEntity>();

            CreateMap<ParticipantEntity, PostParticipant>();

            CreateMap<ParticipantEntity, GridParticipant>();
        }
    }
}
