﻿using BolsaCasa.CrossCutting.DTO.Participant;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Service.Modules
{
    public interface IParticipantService
    {
        Task<bool> AddAsync(PostParticipant dto);
        Task<dynamic> GetProcessoById(int idProcesso);

        //Task<GridView<MemorandoGridDTO>> FindByFilter(Filter filter, CancellationToken ct = default);
    }
    public class ParticipantService
    {

    }
}
