﻿using BolsaCasa.Domain.Entities;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.Repository
{
    public interface IParticipantRepository
    {
        Task<ParticipantEntity> FindByIdAsync(int id);
        Task<ParticipantEntity> AddAsync(ParticipantEntity entity);
        Task<ParticipantEntity> EditAsync(ParticipantEntity entity);
        IQueryable<ParticipantEntity> Filter(string id);
    }
    public class ParticipantRepository : IParticipantRepository
    {
        public Task<ParticipantEntity> AddAsync(ParticipantEntity entity)
        {
            throw new NotImplementedException();
        }

        public Task<ParticipantEntity> EditAsync(ParticipantEntity entity)
        {
            throw new NotImplementedException();
        }

        public IQueryable<ParticipantEntity> Filter(string id)
        {
            throw new NotImplementedException();
        }

        public Task<ParticipantEntity> FindByIdAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}
