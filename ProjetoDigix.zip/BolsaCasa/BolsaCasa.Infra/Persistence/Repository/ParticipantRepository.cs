﻿using BolsaCasa.CrossCutting.DTO.Participant;
using BolsaCasa.Domain.Entities;
using BolsaCasa.Infra.Persistence.EntityFramework;
using BolsaCasa.Infra.Persistence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.Repository
{
    public interface IParticipantRepository
    {
        Task<ParticipantEntity> FindByIdAsync(int id);
        Task<ParticipantEntity> AddAsync(ParticipantEntity entity);
        Task<ParticipantEntity> EditAsync(ParticipantEntity entity);
        IQueryable<List<GridParticipant>> GetGridParticipants();
        IQueryable<ParticipantEntity> Filter(string id);
    }
    public class ParticipantRepository : GenericRepositoryy<ParticipantEntity, BolsaCasaModel>, IParticipantRepository
    {
        public ParticipantRepository(BolsaCasaModel context) : base(context)
        {
        }
        public Task<ParticipantEntity> AddAsync(ParticipantEntity entity)
        {
            throw new NotImplementedException();
        }

        public Task<ParticipantEntity> EditAsync(ParticipantEntity entity)
        {
            throw new NotImplementedException();
        }

        public IQueryable<ParticipantEntity> Filter(string id)
        {
            throw new NotImplementedException();
        }

        public Task<ParticipantEntity> FindByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async IQueryable<List<GridParticipant>> GetGridParticipants()
        {
            var result = await _context.Participant.ToList();
            return result;
        }
    }
}
