﻿using BolsaCasa.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.Model
{
    public partial class BolsaCasaModel : DbContext
    {
        public DbSet<ParticipantEntity> Participant { get; set; }

        public BolsaCasaModel(DbContextOptions options) : base(options)
        {
        }
    }
}
