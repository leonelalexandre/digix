﻿using BolsaCasa.Infra.Persistence.Model;
using BolsaCasa.Infra.Persistence.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.UnitOfWork
{
    public interface IParticipantUnitOfWork
    {
        ParticipantRepository ParticipantRepository { get; }
    }
    public class ParticipantUnitOfWork : IParticipantUnitOfWork
    {
        public ParticipantUnitOfWork(BolsaCasaModel context,
                               IServiceProvider serviceProvider) : base(context, serviceProvider)
        {
        }

        public ParticipantRepository ParticipantRepository => throw new NotImplementedException();
    }
}
