﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.EntityFramework
{
    public class GenericRepositoryy<TEntity, TContext> : IRepository<TEntity>
        where TEntity : class
        where TContext : DbContext
    {
        protected readonly TContext _context;

        private readonly DbSet<TEntity> _dbSet;

        public GenericRepositoryy(TContext context)
        {
            _dbSet = context.Set<TEntity>();
            _context = context;
        }

        public IQueryable<TEntity> GetAll()
        {
            return _dbSet;
        }

        public IQueryable<TEntity> GetAllReadOnly()
        {
            return _dbSet.AsNoTracking();
        }

        public TEntity GetById(int id)
        {
            return _dbSet.Find(new object[] { id });
        }

        public virtual void MassDelete(List<TEntity> entities)
        {
            _dbSet.RemoveRange(entities);
        }

        public virtual void MassDelete(ICollection<TEntity> entities)
        {
            _dbSet.RemoveRange(entities);
        }

        public virtual void MassDelete(IQueryable<TEntity> entities)
        {
            _dbSet.RemoveRange(entities);
        }

        public virtual void Add(TEntity entity)
        {
            _dbSet.Add(entity);
        }

        public virtual void Delete(TEntity entity)
        {
            _dbSet.Remove(entity);
        }


        public void Edit(TEntity entity, string propertyName)
        {
            _context.Entry(entity).Property(propertyName).IsModified = true;
        }

        public void Edit(TEntity entity, string[] propertysName)
        {
            if (propertysName != null && propertysName.Any())
            {
                foreach (var property in propertysName)
                    Edit(entity, property);
            }
        }

        public void Attach(TEntity entity)
        {
            _dbSet.Attach(entity);
        }

        public void MassAdd(List<TEntity> entities)
        {
            _dbSet.AddRange(entities);
        }

        public virtual async Task<TEntity> GetByIdAsync(long id)
        {
            return await _dbSet.FindAsync(new object[] { id });
        }

        public virtual async Task<TEntity> GetByIdAsync(int id)
        {
            return await _dbSet.FindAsync(new object[] { id });
        }

        public virtual async Task AddAsync(TEntity entity)
        {
            await _dbSet.AddAsync(entity);
        }

        public virtual async Task MassAddAsync(List<TEntity> entities)
        {
            await _dbSet.AddRangeAsync(entities);
        }
    }
}
