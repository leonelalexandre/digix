﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.EntityFramework
{
    public interface IRepository<TEntity>
    {
        IQueryable<TEntity> GetAll();
        IQueryable<TEntity> GetAllReadOnly();
        TEntity GetById(int id);
        void MassDelete(List<TEntity> entities);
        void MassDelete(ICollection<TEntity> entities);
        void MassDelete(IQueryable<TEntity> entities);
        void Add(TEntity entity);
        void Delete(TEntity entity);
        void Attach(TEntity entity);
        void Edit(TEntity entity, string propertyName);
        void Edit(TEntity entity, string[] propertysName);
        void MassAdd(List<TEntity> entities);
        Task AddAsync(TEntity entity);

        Task<TEntity> GetByIdAsync(int id);

    }
}
