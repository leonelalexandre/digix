﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class FilterItem
    {
        public string Campo { get; set; }
        public string CampoExibido { get; set; }
        public bool MostrarColuna { get; set; }
        public bool RemoverColuna { get; set; }
        public bool SomenteNull { get; set; }
        public bool OuNulo { get; set; }
        public List<GenericFilterInput> entradas { get; set; }
        public string Tipo { get; set; }
        public bool ApenasData { get; set; }
        public int? DecimalPlaces { get; set; }
        public List<ListFilterInput> ListaFiltro { get; set; }
        public bool IgnorarCase { get; set; }
        public string GridDinamica { get; set; }

        public Expression SetLeftProperties(ParameterExpression pe)
        {
            string[] columns = Campo.Split('.');
            Expression left = Expression.Property(pe, columns[0]);
            if (columns.Count() != 1)
            {
                for (int i = 1; i < columns.Count(); i++)
                {
                    if (columns[i].Equals("First()"))
                    {
                        MethodInfo findMethod = null;

                        var methods = typeof(Enumerable).GetMethods(BindingFlags.Static | BindingFlags.Public)
                            .Where(m => m.Name == "FirstOrDefault");

                        foreach (var methodInfo in methods)
                        {
                            if (methodInfo.GetParameters().Length == 1)
                            {
                                findMethod = methodInfo;
                            }
                        }

                        findMethod = findMethod.MakeGenericMethod((left.Type.GenericTypeArguments[0]).UnderlyingSystemType);
                        left = Expression.Call(null, findMethod, left);
                    }
                    else
                    {
                        left = Expression.Property(left, columns[i]);
                    }
                }
            }
            return left;
        }

        public static FilterItem DateFieldGreaterOrEquals(string fieldName, string date)
        {
            return new FilterItem
            {
                Campo = fieldName,
                entradas = new List<GenericFilterInput>
                {
                    new DateGreaterThanOrEqualFilterInput(value: date, valueTime: null, isNullable: false)
                }
            };
        }

        public static FilterItem TextFieldContains(string fieldName, string containsThisText)
        {
            return new FilterItem
            {
                Campo = fieldName,
                entradas = new List<GenericFilterInput>
                {
                    new TextContainsFilterInput(value: containsThisText, ignorarCase: false, naoCoincidentes: false, valoresBuscaAvancada: null, tipoBuscaAvancada: null)
                }
            };
        }

        public static FilterItem NumberFieldEquals(string fieldName, long equalsThisNumber)
        {
            return new FilterItem
            {
                Campo = fieldName,
                entradas = new List<GenericFilterInput>
                {
                    new NumberEqualsFilterInput(equalsThisNumber, "AND")
                }
            };
        }
    }
}
