﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    
    public class Filter
    {
        public int pageSize { get; set; }
        public int pageNumber { get; set; }
        public String recurso { get; set; }
        public object preFilter { get; set; }
        public Dictionary<string, object> Parameters { get; set; }
        public List<FilterItem> FilterItens { get; set; }
        public List<FilterOrder> FilterOrder { get; set; }

        public static Filter CreateFilterFromJson(dynamic filtersValues)
        {
            var filterItens = new List<FilterItem>();
            foreach (dynamic itens in filtersValues.filterItens)
            {
                if (itens.inputs.HasValues)
                {
                    var DecimalPlaces = itens.places == null ? default(int?) : itens.places.Value;

                    var filterItem = new FilterItem
                    {
                        Tipo = itens.type,
                        Campo = itens.dataName.Value,
                        CampoExibido = itens.fieldName.Value,
                        MostrarColuna = itens.show.Value,
                        RemoverColuna = itens.removeColumn == null ? false : itens.removeColumn.Value,
                        ApenasData = itens.onlyDate == null ? false : itens.onlyDate.Value,
                        DecimalPlaces = itens.places == null ? 2 : Convert.ToInt32(itens.places.Value),
                        entradas = new List<GenericFilterInput>(),
                        ListaFiltro = new List<ListFilterInput>(),
                        SomenteNull = itens.inputs[0].SomenteNull == null ? false : itens.inputs[0].SomenteNull.Value,
                        OuNulo = itens.inputs[0].ouNulo == null ? false : itens.inputs[0].ouNulo.Value,
                        IgnorarCase = itens.ignoreCase == null ? true : itens.ignoreCase.Value,
                        GridDinamica = filtersValues.dynamicGrid
                    };

                    foreach (dynamic input in itens.inputs)
                    {
                        var inputItem = FilterInputFactory.CriarInput(input, filterItem);
                        if (inputItem != null)
                            filterItem.entradas.Add(inputItem);
                    }


                    if (itens.array != null && itens.type.ToString() == "lista")
                    {
                        foreach (dynamic array in itens.array)
                        {
                            var listaFriltroDto = new ListFilterInput() { Value = array.value.ToString(), Label = array.label.ToString() };
                            filterItem.ListaFiltro.Add(listaFriltroDto);
                        }

                    }

                    filterItens.Add(filterItem);
                }
            }

            var filterOrderList = new List<FilterOrder>();
            foreach (dynamic orderItem in filtersValues.filterOrder)
            {
                var filterOrderItem = new FilterOrder
                {
                    Field = orderItem.dataName.Value,
                    order = orderItem.order.Value
                };
                filterOrderList.Add(filterOrderItem);
            }

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (filtersValues.parameters != null)
                foreach (dynamic parameter in filtersValues.parameters)
                {
                    if (parameter.Valor == null)
                        parameters[parameter.Nome.Value] = null;
                    else if (parameter.Valor.Type.ToString() == typeof(Array).Name)
                        parameters[parameter.Nome.Value] = parameter.Valor;
                    else
                        parameters[parameter.Nome.Value] = parameter.Valor.Value;
                }


            var filter = new Filter { FilterItens = new List<FilterItem>(), FilterOrder = new List<FilterOrder>() };

            filter.FilterItens = filterItens;
            filter.FilterOrder = filterOrderList;
            filter.pageSize = filtersValues.pageSize;
            filter.pageNumber = filtersValues.pageNumber;
            filter.recurso = filtersValues.recurso;
            filter.Parameters = parameters;
            filter.preFilter = filtersValues.preFilter;

            return filter;
        }

        public IEnumerable<FilterItem> MapFilter(string field)
        {
            return FilterItens.Where(x => x.Campo == field);
        }

        public Filter Map(string field, string to)
        {
            foreach (var item in FilterItens.Where(x => x.Campo == field))
                item.Campo = to;

            foreach (var item in FilterOrder.Where(x => x.Field == field))
                item.Field = to;

            return this;
        }

        public Filter RemoveAll(string field)
        {
            FilterItens.RemoveAll(x => x.Campo == field);
            FilterOrder.RemoveAll(x => x.Field == field);
            return this;
        }

        public bool IsFiltered()
        {
            foreach (var item in FilterItens)
            {
                foreach (var input in item.entradas)
                {
                    if (input.Valor != null || input.EhBuscaAvancada)
                        return true;
                }
            }
            return false;
        }

    }
}
