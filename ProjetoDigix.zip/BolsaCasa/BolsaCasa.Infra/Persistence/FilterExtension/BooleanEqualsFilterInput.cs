﻿using System;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class BooleanEqualsFilterInput : GenericFilterInput
    {
        public BooleanEqualsFilterInput(object value, string tipoConcatenacao) : base(value, tipoConcatenacao) => TypeName = "BooleanEqualsFilterInput";

        public override Expression GetExpression(Expression left, string campo) =>
            Expression.Equal(Expression.Convert(left, typeof(bool)), Expression.Constant(Convert.ToBoolean(Valor), typeof(bool)));
    }
}
