﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class DateLessThanOrEqualFilterInput :GenericFilterInput
    {
        public bool IsNullable { get; set; }
        public DateTime DataFormatada { get; set; }

        public DateLessThanOrEqualFilterInput(object value, object valueTime, bool isNullable)
            : base(value)
        {
            var minute = 00;
            var hour = 00;
            var second = 00;

            if (valueTime != null && !string.IsNullOrEmpty(valueTime.ToString()))
            {
                hour = Convert.ToInt32(valueTime.ToString().Substring(0, 2));
                minute = Convert.ToInt32(valueTime.ToString().Substring(3, 2));
                second = Convert.ToInt32(valueTime.ToString().Substring(6, 2));

                ValidateTime(minute, hour, second);
            }

            if (value != null && !string.IsNullOrEmpty(value.ToString()))
            {
                var day = Convert.ToInt32(value.ToString().Substring(0, 2));
                var month = Convert.ToInt32(value.ToString().Substring(3, 2));
                var year = Convert.ToInt32(value.ToString().Substring(6, 4));

                ValidateDate(day, month, year);

                DataFormatada = new DateTime(year, month, day, hour, minute, second);
            }

            IsNullable = isNullable;

            TypeName = "DateLessThanOrEqualFilterInput";
        }

        private static void ValidateDate(int day, int month, int year)
        {
            if (day > 31)
                throw new Exception("Dia do mês inválido no filtro Data de Abertura!");

            if (month > 12)
                throw new Exception("Mês inválido no filtro Data de Abertura!");
        }

        private static void ValidateTime(int minute, int hour, int second)
        {
            if (hour >= 24)
                throw new Exception("Hora inválida no filtro Data de Abertura!");

            if (minute >= 60)
                throw new Exception("Minutos inválidos no filtro Data de Abertura!");

            if (second >= 60)
                throw new Exception("Segundos inválidos no filtro Data de Abertura!");
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            left = Expression.LessThanOrEqual(Expression.Convert(left, typeof(DateTime?)), Expression.Constant(DataFormatada, typeof(DateTime?)));
            return left;
        }
    }
}
