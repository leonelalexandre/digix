﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class NumberAdvancedFilterInput : GenericFilterInput
    {
        public bool ehDecimal { get; protected set; }
        public bool ehAnulavel { get; protected set; }
        public bool ehLong { get; protected set; }
        public bool ehShort { get; protected set; }
        public bool ehByte { get; protected set; }

        public List<string> valoresBuscaAvancada { get; protected set; }
        public bool naoCoincidentes { get; protected set; }

        public NumberAdvancedFilterInput(object value, bool _ehDecimal, bool _ehAnulavel, bool _ehLong, bool _ehShort, bool _ehByte, List<string> _valoresBuscaAvancada, bool _naoCoincidentes)
            : base(value)
        {
            ehDecimal = _ehDecimal;
            ehAnulavel = _ehAnulavel;
            ehLong = _ehLong;
            ehShort = _ehShort;
            ehByte = _ehByte;
            valoresBuscaAvancada = _valoresBuscaAvancada;
            naoCoincidentes = _naoCoincidentes;
            EhBuscaAvancada = valoresBuscaAvancada.Any();

            TypeName = "NumberAdvancedFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            Expression advancedSearchExpression = null;
            if (ehDecimal)
                if (ehAnulavel)
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(decimal?)), Expression.Constant(Convert.ToDecimal(valoresBuscaAvancada[0], new CultureInfo("en-US")), typeof(decimal?)));
                else
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(decimal)), Expression.Constant(Convert.ToDecimal(valoresBuscaAvancada[0], new CultureInfo("en-US")), typeof(decimal)));
            else if (ehLong)
                if (ehAnulavel)
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int64?)), Expression.Constant(Convert.ToInt64(valoresBuscaAvancada[0]), typeof(Int64?)));
                else
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int64)), Expression.Constant(Convert.ToInt64(valoresBuscaAvancada[0]), typeof(Int64)));
            else if (ehShort)
                if (ehAnulavel)
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int16?)), Expression.Constant(Convert.ToInt16(valoresBuscaAvancada[0]), typeof(Int16?)));
                else
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int16)), Expression.Constant(Convert.ToInt16(valoresBuscaAvancada[0]), typeof(Int16)));
            else if (ehByte)
                if (ehAnulavel)
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(byte?)), Expression.Constant(Convert.ToByte(valoresBuscaAvancada[0]), typeof(byte?)));
                else
                    advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(byte)), Expression.Constant(Convert.ToByte(valoresBuscaAvancada[0]), typeof(byte)));
            else
                if (ehAnulavel)
                advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int32?)), Expression.Constant(Convert.ToInt32(valoresBuscaAvancada[0]), typeof(Int32?)));
            else
                advancedSearchExpression = Expression.Equal(Expression.Convert(left, typeof(Int32)), Expression.Constant(Convert.ToInt32(valoresBuscaAvancada[0]), typeof(Int32)));

            for (var i = 1; i < valoresBuscaAvancada.Count; i++)
            {
                advancedSearchExpression = Expression.Or(advancedSearchExpression,
                    Expression.Equal(Expression.Convert(left, typeof(Decimal)), Expression.Constant(Convert.ToDecimal(valoresBuscaAvancada[i], new CultureInfo("en-US")), typeof(Decimal))));
            }

            return HandleApplyNot(advancedSearchExpression);
        }

        protected Expression HandleApplyNot(Expression left)
        {
            if (naoCoincidentes)
            {
                left = Expression.Not(left);
            }
            return left;
        }
    }
}
