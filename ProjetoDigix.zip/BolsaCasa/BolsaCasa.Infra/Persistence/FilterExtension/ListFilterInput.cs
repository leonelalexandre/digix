﻿namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class ListFilterInput
    {
        public string Value { get; set; }
        public string Label { get; set; }
    }
}
