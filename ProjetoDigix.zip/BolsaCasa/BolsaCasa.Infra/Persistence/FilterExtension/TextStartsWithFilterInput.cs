﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class TextStartsWithFilterInput : TextFilterInput
    {
        public TextStartsWithFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value, ignorarCase, naoCoincidentes, valoresBuscaAvancada, tipoBuscaAvancada)
        {
            TypeName = "TextStartsWithFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            var stringStartsWithMethod = typeof(string).GetMethod("StartsWith", new[] { typeof(string) });
            return !ValoresBuscaAvancada.Any() ? ApplyCaseAndIsNot(left, stringStartsWithMethod, Valor.ToString()) : ApplyAdvancedSearch(left, stringStartsWithMethod);
        }
    }
}
