﻿using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public abstract class GenericFilterInput
    {
        public GenericFilterInput(object value)
        {
            TipoConcatenacao = "AND";
            Valor = value;
            TypeName = "GenericFilterInput";
        }

        public GenericFilterInput(object value, string tipoConcatenacao)
        {
            TipoConcatenacao = tipoConcatenacao;
            Valor = value;
            TypeName = "GenericFilterInput";
        }

        public string TypeName { get; set; }
        public object Valor { get; set; }
        public string TipoConcatenacao { get; set; }
        public bool EhBuscaAvancada { get; set; }
        public abstract Expression GetExpression(Expression left, string campo = null);
    }
}
