﻿using System;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class NumberEqualsFilterInput : GenericFilterInput
    {
        public NumberEqualsFilterInput(object value, string tipoConcatenacao)
            : base(value, tipoConcatenacao)
        {
            TypeName = "NumberEqualsFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            return Expression.Equal(Expression.Convert(left, typeof(Int32)), Expression.Constant(Convert.ToInt32(Valor), typeof(Int32)));
        }
    }
}
