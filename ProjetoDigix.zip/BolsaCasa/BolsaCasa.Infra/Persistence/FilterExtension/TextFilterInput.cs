﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public abstract class TextFilterInput : GenericFilterInput
    {
        public bool IgnorarCase { get; protected set; }
        public bool NaoCoincidentes { get; protected set; }
        public List<string> ValoresBuscaAvancada { get; protected set; }
        public string TipoBuscaAvancada { get; protected set; }

        protected TextFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value)
        {
            IgnorarCase = ignorarCase;
            NaoCoincidentes = naoCoincidentes;
            ValoresBuscaAvancada = valoresBuscaAvancada;
            TipoBuscaAvancada = tipoBuscaAvancada;
            EhBuscaAvancada = ValoresBuscaAvancada.Any();
            TypeName = "TextFilterInput";
        }

        protected Expression ApplyCaseAndIsNot(Expression left, MethodInfo method, string value)
        {
            left = HandleApplyCase(left, method, value);
            left = HandleApplyNot(left);
            return left;
        }

        protected Expression HandleApplyCase(Expression left, MethodInfo method, string value)
        {
            if (IgnorarCase)
            {
                left = Expression.Call(left, typeof(string).GetMethod("ToUpper", Type.EmptyTypes));
                left = Expression.Call(left, method, Expression.Constant(value.ToUpper()));
            }
            else
            {
                left = Expression.Call(left, method, Expression.Constant(value));
            }
            return left;
        }

        protected Expression HandleApplyNot(Expression left)
        {
            if (NaoCoincidentes)
            {
                left = Expression.Not(left);
            }
            return left;
        }

        protected Expression ApplyAdvancedSearch(Expression left, MethodInfo method)
        {
            Expression advancedSearchExpression = HandleApplyCase(left, method, ValoresBuscaAvancada[0]);

            for (var i = 1; i < ValoresBuscaAvancada.Count; i++)
            {
                switch (TipoBuscaAvancada)
                {
                    case "or":
                        advancedSearchExpression = Expression.Or(advancedSearchExpression, HandleApplyCase(left, method, ValoresBuscaAvancada[i]));
                        break;
                    case "and":
                        advancedSearchExpression = Expression.And(advancedSearchExpression, HandleApplyCase(left, method, ValoresBuscaAvancada[i]));
                        break;
                }
            }

            return HandleApplyNot(advancedSearchExpression);
        }
    }
}
