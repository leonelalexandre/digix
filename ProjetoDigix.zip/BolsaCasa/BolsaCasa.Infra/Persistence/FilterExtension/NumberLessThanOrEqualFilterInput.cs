﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class NumberLessThanOrEqualFilterInput : GenericFilterInput
    {
        public bool EhDecimal { get; set; }
        public bool EhAnulavel { get; set; }
        public bool EhLong { get; set; }
        public bool EhShort { get; set; }
        public bool EhByte { get; set; }

        public NumberLessThanOrEqualFilterInput(object value, bool ehDecimal, bool ehAnulavel, bool ehLong, bool ehShort, bool ehByte)
            : base(value)
        {
            EhDecimal = ehDecimal;
            EhAnulavel = ehAnulavel;
            EhLong = ehLong;
            EhShort = ehShort;
            EhByte = ehByte;
            TypeName = "NumberLessThanOrEqualFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            if (EhDecimal)
                if (EhAnulavel)
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToDecimal(Valor, new CultureInfo("en-US")), typeof(decimal?)));
                else
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToDecimal(Valor, new CultureInfo("en-US")), typeof(decimal)));
            if (EhAnulavel)
                if (EhLong)
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt64(Valor), typeof(long?)));
                else
                if (EhShort)
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt16(Valor), typeof(short?)));
                else
                if (EhByte)
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToByte(Valor), typeof(byte?)));
                else
                    return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt32(Valor), typeof(int?)));
            if (EhLong)
                return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt64(Valor), typeof(long)));
            if (EhShort)
                return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt16(Valor), typeof(short)));
            if (EhByte)
                return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToByte(Valor), typeof(byte)));

            return Expression.LessThanOrEqual(left, Expression.Constant(Convert.ToInt32(Valor), typeof(int)));
        }
    }
}
