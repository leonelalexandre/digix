﻿using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class TextContainsFilterInput : TextFilterInput
    {
        public TextContainsFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value, ignorarCase, naoCoincidentes, valoresBuscaAvancada, tipoBuscaAvancada)
        {
            TypeName = "TextContainsFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            var stringContainsMethod = typeof(string).GetMethod("Contains", new[] { typeof(string) });
            return !ValoresBuscaAvancada.Any() ? ApplyCaseAndIsNot(left, stringContainsMethod, Valor.ToString()) : ApplyAdvancedSearch(left, stringContainsMethod);
        }
    }
}
