﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class ContaLessThanOrEqualFilterInput : TextFilterInput
    {
        public ContaLessThanOrEqualFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value, ignorarCase, naoCoincidentes, valoresBuscaAvancada, tipoBuscaAvancada)
        {
            TypeName = "ContaLessThanOrEqualFilterInput";
        }

        public override Expression GetExpression(Expression pe, string campo)
        {
            return HandleSingleMaskLessThanOrEqualInput(pe, campo, Valor.ToString());
        }

        private Expression HandleSingleMaskLessThanOrEqualInput(Expression pe, string campo, string valor)
        {
            //MethodInfo PatIndexMethod = typeof(SqlFunctions).GetMethod("PatIndex");
            MethodInfo PatIndexMethod = EF.Functions.GetType().GetMethod("Like");
            ConstantExpression ValueZero = Expression.Constant(0, typeof(int?));

            var patternStringArg = Expression.Constant(valor);

            var columns = campo.Split('.');
            Expression left = Expression.Property(pe, columns[0]);

            if (columns.Count() != 1)
            {
                for (int i = 1; i < columns.Count(); i++)
                {
                    left = Expression.Property(left, columns[i]);
                }
            }

            left = Expression.Call(left, typeof(string).GetMethod("Trim", Type.EmptyTypes));

            string valueReplaced = valor.Replace("_", "9");
            ConstantExpression limitValue = Expression.Constant(valueReplaced);

            Expression LessThanOrEqual = Expression.LessThanOrEqual(
                            Expression.Call(typeof(string), "Compare", null, new[] { left, limitValue }),
                             Expression.Constant(0, typeof(int)));

            return LessThanOrEqual;
        }
    }
}
