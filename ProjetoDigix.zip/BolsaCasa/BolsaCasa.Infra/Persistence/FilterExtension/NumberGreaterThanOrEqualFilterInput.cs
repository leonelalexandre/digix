﻿using System;
using System.Globalization;
using System.Linq.Expressions;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class NumberGreaterThanOrEqualFilterInput : GenericFilterInput
    {
        public bool EhDecimal { get; set; }
        public bool EhAnulavel { get; set; }
        public bool EhLong { get; set; }
        public bool EhShort { get; set; }
        public bool EhByte { get; set; }

        public NumberGreaterThanOrEqualFilterInput(object value, bool ehDecimal, bool ehAnulavel, bool ehLong, bool ehShort, bool ehByte) : base(value)
        {
            EhDecimal = ehDecimal;
            EhAnulavel = ehAnulavel;
            EhLong = ehLong;
            EhShort = ehShort;
            EhByte = ehByte;
            TypeName = "NumberGreaterThanOrEqualFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            if (EhDecimal)
                if (EhAnulavel)
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToDecimal(Valor, new CultureInfo("en-US")), typeof(decimal?)));
                else
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToDecimal(Valor, new CultureInfo("en-US")), typeof(decimal)));
            if (EhAnulavel)
                if (EhLong)
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt64(Valor), typeof(long?)));
                else
                if (EhShort)
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt16(Valor), typeof(short?)));
                else
                if (EhByte)
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToByte(Valor), typeof(byte?)));
                else
                    return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt32(Valor), typeof(int?)));
            if (EhLong)
                return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt64(Valor), typeof(long)));
            if (EhShort)
                return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt16(Valor), typeof(short)));
            if (EhByte)
                return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToByte(Valor), typeof(byte)));

            return Expression.GreaterThanOrEqual(left, Expression.Constant(Convert.ToInt32(Valor), typeof(int)));
        }
    }
}
