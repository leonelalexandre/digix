﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class ContaGreaterThanOrEqualFilterInput : TextFilterInput
    {
        public ContaGreaterThanOrEqualFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value, ignorarCase, naoCoincidentes, valoresBuscaAvancada, tipoBuscaAvancada)
        {
            TypeName = "ContaGreaterThanOrEqualFilterInput";
        }
        public override Expression GetExpression(Expression pe, string campo)
        {
            return HandleSingleMaskGreaterThanOrEqualInput(pe, campo, Valor.ToString());
        }

        private Expression HandleSingleMaskGreaterThanOrEqualInput(Expression pe, string campo, string valor)
        {
            //MethodInfo PatIndexMethod = typeof(SqlFunctions).GetMethod("PatIndex");

            MethodInfo PatIndexMethod = EF.Functions.GetType().GetMethod("Like");

            ConstantExpression ValueZero = Expression.Constant(0, typeof(int?));

            var patternStringArg = Expression.Constant(valor);

            var columns = campo.Split('.');
            Expression left = Expression.Property(pe, columns[0]);

            if (columns.Count() != 1)
            {
                for (int i = 1; i < columns.Count(); i++)
                {
                    left = Expression.Property(left, columns[i]);
                }
            }

            left = Expression.Call(left, typeof(string).GetMethod("Trim", Type.EmptyTypes));
            ConstantExpression limitValue = Expression.Constant(valor);

            Expression GreatherThanOrEqual = Expression.GreaterThanOrEqual(
                            Expression.Call(typeof(string), "Compare", null, new[] { left, limitValue }),
                             Expression.Constant(0, typeof(int)));

            return GreatherThanOrEqual;
        }
    }
}
