﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public static class FilterInputFactory
    {
        private const string OR = "OR";
        private const string AND = "AND";

        public static GenericFilterInput CriarInput(dynamic input, FilterItem filterItem)
        {
            GenericFilterInput filterInput = null;
            if (input.type == "text")
            {
                var advancedSearchValues = input.advancedSearchValues == null ? new List<string>() : input.advancedSearchValues.ToObject<List<string>>();
                var advancedSearchOperator = input.advancedSearchOperator == null ? null : input.advancedSearchOperator.Value;
                var isNot = input.isNot != null ? input.isNot.Value : false;
                //var isNotCase = input.isNotCase != null ? input.isNotCase.Value : true;

                if (input.operation.Value == "startsWith")
                {
                    filterInput = new TextStartsWithFilterInput(input.value != null ? input.value.Value : null, filterItem.IgnorarCase, isNot, advancedSearchValues, advancedSearchOperator);
                }
                else if (input.operation.Value == "contains")
                {
                    filterInput = new TextContainsFilterInput(input.value != null ? input.value.Value : null, filterItem.IgnorarCase, isNot, advancedSearchValues, advancedSearchOperator);
                }
            }
            else if (input.type == "number" || input.type == "decimal")
            {
                var isNot = input.isNot != null ? input.isNot.Value : false;

                List<string> advancedSearchValues = input.advancedSearchValues == null ? new List<string>() : input.advancedSearchValues.ToObject<List<string>>();

                if (advancedSearchValues.Any())
                {
                    filterInput = new NumberAdvancedFilterInput(input.value != null ? input.value.Value : null, input.type == "decimal",
                            input.isNullable.Value, input.isLong.Value, input.isShort.Value, input.isByte.Value, advancedSearchValues, isNot);
                }
                else
                {
                    if (input.operation.Value == "de")
                    {
                        filterInput = new NumberGreaterThanOrEqualFilterInput(input.value != null ? input.value.Value : null, input.type == "decimal",
                            input.isNullable.Value, input.isLong.Value, input.isShort.Value, input.isByte.Value);
                    }
                    else if (input.operation.Value == "ate")
                    {
                        filterInput = new NumberLessThanOrEqualFilterInput(input.value != null ? input.value.Value : null, input.type == "decimal",
                            input.isNullable.Value, input.isLong.Value, input.isShort.Value, input.isByte.Value);
                    }
                }
            }
            else if (input.type == "lista")
            {
                filterInput = CriarListaInput(input);
            }
            else if (input.type == "icon-group")
            {
                if (input.arrayType.Value == "text" && input.check.Value)
                {
                    filterInput = new TextEqualsFilterInput(input.value != null ? input.value.Value : null, OR);
                }
                else if (input.arrayType.Value == "number" && input.check.Value)
                {
                    filterInput = new NumberEqualsFilterInput(input.value != null ? input.value.Value : null, OR);
                }
            }
            else if (input.type == "date")
            {
                try
                {
                    if (input.operation.Value == "sinceDate")
                    {
                        filterInput = new DateGreaterThanOrEqualFilterInput(input.value != null ? input.value.Value : null, input.valueTime != null ? input.valueTime.Value : null, input.isNullable.Value);
                    }
                    else if (input.operation.Value == "untilDate")
                    {
                        filterInput = new DateLessThanOrEqualFilterInput(input.value != null ? input.value.Value : null, input.valueTime != null ? input.valueTime.Value : null, input.isNullable.Value);
                    }
                }
                catch
                {
                    return filterInput;
                }

            }
            else if (input.type == "conta")
            {
                List<string> advancedSearchValues = input.advancedSearchValues == null ? new List<string>() : input.advancedSearchValues.ToObject<List<string>>();
                var isSearchByFaixa = input.isSearchByFaixa != null ? input.isSearchByFaixa.Value : false;
                var isNot = input.isNot != null ? input.isNot.Value : false;
                var advancedSearchOperator = input.advancedSearchOperator == null ? isNot ? "and" : "or" : input.advancedSearchOperator.Value;

                if (advancedSearchValues.Any() || input.operation.Value == "contains")
                {
                    filterInput = new ContaContainsFilterInput(input.value != null ? input.value.Value : null, false, isNot, advancedSearchValues, advancedSearchOperator);
                }
                else
                {
                    if (!isSearchByFaixa)
                        filterInput = new ContaContainsFilterInput(input.value != null ? input.value.Value : null, false, isNot, advancedSearchValues, advancedSearchOperator);
                    else
                        if (input.operation.Value == "de")
                        filterInput = new ContaGreaterThanOrEqualFilterInput(input.value != null ? input.value.Value : null, false, false, advancedSearchValues, advancedSearchOperator);
                    else
                            if (input.operation.Value == "ate")
                        filterInput = new ContaLessThanOrEqualFilterInput(input.value != null ? input.value.Value : null, false, false, advancedSearchValues, advancedSearchOperator);
                }
            }
            else if (input.type == "birthday")
            {
                List<string> advancedSearchValues = input.advancedSearchValues == null ? new List<string>() : input.advancedSearchValues.ToObject<List<string>>();
                var isSearchByFaixa = input.isSearchByFaixa != null ? input.isSearchByFaixa.Value : false;
                var isNot = input.isNot != null ? input.isNot.Value : false;
                var advancedSearchOperator = input.advancedSearchOperator == null ? isNot ? "and" : "or" : input.advancedSearchOperator.Value;

                if (advancedSearchValues.Any() || input.operation.Value == "contains")
                {
                    filterInput = new ContaContainsFilterInput(input.value != null ? input.value.Value : null, false, isNot, advancedSearchValues, advancedSearchOperator);
                }
                else
                {
                    if (!isSearchByFaixa)
                        filterInput = new ContaContainsFilterInput(input.value != null ? input.value.Value : null, false, isNot, advancedSearchValues, advancedSearchOperator);
                    else
                        if (input.operation.Value == "de")
                        filterInput = new ContaGreaterThanOrEqualFilterInput(input.value != null ? input.value.Value : null, false, false, advancedSearchValues, advancedSearchOperator);
                    else
                            if (input.operation.Value == "ate")
                        filterInput = new ContaLessThanOrEqualFilterInput(input.value != null ? input.value.Value : null, false, false, advancedSearchValues, advancedSearchOperator);
                }
            }
            else if (input.type == "contanomask")
            {
                List<string> advancedSearchValues = input.advancedSearchValues == null ? new List<string>() : input.advancedSearchValues.ToObject<List<string>>();
                var advancedSearchOperator = input.advancedSearchOperator == null ? null : input.advancedSearchOperator.Value;
                var isSearchByFaixa = input.isSearchByFaixa != null ? input.isSearchByFaixa.Value : false;
                var isNot = input.isNot != null ? input.isNot.Value : false;
                var isNotCase = input.isNotCase != null ? input.isNotCase.Value : false;

                if (input.operation.Value == "startsWith")
                {
                    filterInput = new ContaStartsWithFilterInput(input.value != null ? input.value.Value : null, isNotCase, isNot, advancedSearchValues, advancedSearchOperator);
                }
                else if (input.operation.Value == "contains")
                {
                    filterInput = new ContaContainsFilterInput(input.value != null ? input.value.Value : null, isNotCase, isNot, advancedSearchValues, advancedSearchOperator);
                }

            }


            return filterInput;
        }

#if !NETCOREAPP2_2
        private static GenericFilterInput CriarListaInput(dynamic input) => input.arrayType.Value switch
        {
            "text" when input.check.Value => new TextEqualsFilterInput(input.value?.Value, OR),
            "number" when input.check.Value => new NumberEqualsFilterInput(input.value?.Value, OR),
            "bool" when input.check.Value => new BooleanEqualsFilterInput(input.value?.Value, OR),
            _ => null
        };
#else
        private static GenericFilterInput CriarListaInput(dynamic input)
        {
            switch (input.arrayType.Value)
            {
                case "text" when input.check.Value: return new TextEqualsFilterInput(input.value?.Value, OR);
                case "number" when input.check.Value: return new NumberEqualsFilterInput(input.value?.Value, OR);
                case "bool" when input.check.Value: return new BooleanEqualsFilterInput(input.value?.Value, OR);
                default: return null;
            };
        }
#endif

    }
}
