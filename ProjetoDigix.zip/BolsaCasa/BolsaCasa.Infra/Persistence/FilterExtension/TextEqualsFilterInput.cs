﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class TextEqualsFilterInput : GenericFilterInput
    {
        public TextEqualsFilterInput(object value, string tipoConcatenacao)
            : base(value, tipoConcatenacao)
        {
            TypeName = "TextEqualsFilterInput";
        }

        public override Expression GetExpression(Expression left, string campo)
        {
            MethodInfo method = typeof(string).GetMethod("Equals", new[] { typeof(string) });
            left = Expression.Call(left, method, Expression.Constant(Valor));
            return left;
        }
    }
}
