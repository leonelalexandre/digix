﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class ContaStartsWithFilterInput : TextFilterInput
    {
        public ContaStartsWithFilterInput(object value, bool ignorarCase, bool naoCoincidentes, List<string> valoresBuscaAvancada, string tipoBuscaAvancada)
            : base(value, ignorarCase, naoCoincidentes, valoresBuscaAvancada, tipoBuscaAvancada)
        {
            TypeName = "ContaStartsWithFilterInput";
        }

        public override Expression GetExpression(Expression pe, string campo)
        {
            return !ValoresBuscaAvancada.Any() ? HandleSingleMaskInput(pe, campo, Valor.ToString()) : HandleAdvancedMaskSearch(pe, campo);
        }

        private Expression HandleSingleMaskInput(Expression pe, string campo, string valor)
        {
            MethodInfo likeMethod = typeof(DbFunctionsExtensions).GetMethod("Like", new[] { typeof(DbFunctions), typeof(string), typeof(string) });
            ConstantExpression defaultBoolean = Expression.Constant(true, typeof(bool));

            var patternStringArg = Expression.Constant(valor + "%");

            var columns = campo.Split('.');
            Expression left = Expression.Property(pe, columns[0]);

            if (columns.Count() != 1)
            {
                for (int i = 1; i < columns.Count(); i++)
                {
                    left = Expression.Property(left, columns[i]);
                }
            }

            left = Expression.Call(left, typeof(string).GetMethod("Trim", Type.EmptyTypes));
            MethodCallExpression likeCall = Expression.Call(likeMethod, Expression.Constant(EF.Functions), left, patternStringArg);

            var isEqual = Expression.Equal(likeCall, defaultBoolean);

            if (NaoCoincidentes)
                return Expression.Not(isEqual);

            return isEqual;
        }

        private Expression HandleAdvancedMaskSearch(Expression pe, string campo)
        {
            Expression advancedSearchExpression = HandleSingleMaskInput(pe, campo, ValoresBuscaAvancada[0]);

            for (var i = 1; i < ValoresBuscaAvancada.Count; i++)
            {
                switch (TipoBuscaAvancada)
                {
                    case "or":
                        advancedSearchExpression = Expression.Or(advancedSearchExpression, HandleSingleMaskInput(pe, campo, ValoresBuscaAvancada[i]));
                        break;
                    case "and":
                        advancedSearchExpression = Expression.And(advancedSearchExpression, HandleSingleMaskInput(pe, campo, ValoresBuscaAvancada[i]));
                        break;
                }
            }

            return advancedSearchExpression;
        }
    }
}
