﻿using System;

namespace BolsaCasa.Infra.Persistence.FilterExtension
{
    public class FilterOrder
    {
        public String Field { get; set; }
        public String order { get; set; }
    }
}
