﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BolsaCasa.Domain.Entities
{
    [Table("Participante")]
    public class ParticipantEntity
    {
        [Key]
        [Column("Id")]
        public int Id { get; set; }

        [Column("NameParticipant")]
        public string NameParticipant { get; set; }

        [Column("Income")]
        public decimal Income { get; set; }

        [Column("Point")]
        public int Point { get; set; }
    }
}
